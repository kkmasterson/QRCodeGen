﻿using QRCodeGeneratorLibrary;
using System;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Enter the data to be encoded in the QR code:");
        string data = Console.ReadLine();
        QRGenerator.GenerateQRCode(data);
        Console.WriteLine("QR code generated successfully. Press any key to exit...");
        Console.ReadKey();
    }
}