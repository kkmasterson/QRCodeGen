﻿using QRCoder;
using System.IO;

namespace QRCodeGeneratorLibrary
{
    public class QRGenerator
    {
        public static void GenerateQRCode(string address)
        {
            QRCodeGenerator generator = new QRCodeGenerator();
            QRCodeData qrCodeData = generator.CreateQrCode(address, QRCodeGenerator.ECCLevel.Q);
            QRCoder.BitmapByteQRCode bitmapByteQRCode = new BitmapByteQRCode(qrCodeData);
            byte[] bytes = bitmapByteQRCode.GetGraphic(20);
            using (FileStream fs = new FileStream("Address.bmp", FileMode.Create))
            {
                fs.Write(bytes, 0, bytes.Length);
            }
        }
    }
}